﻿
namespace CoopShop.Administration
{
    using Serenity.Services;
    using System;

    public class UserRoleListResponse : ListResponse<Int32>
    {
    }
}