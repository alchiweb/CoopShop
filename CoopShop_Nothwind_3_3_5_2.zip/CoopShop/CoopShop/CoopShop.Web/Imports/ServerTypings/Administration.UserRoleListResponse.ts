﻿namespace CoopShop.Administration {
    export interface UserRoleListResponse extends Serenity.ListResponse<number> {
    }
}

