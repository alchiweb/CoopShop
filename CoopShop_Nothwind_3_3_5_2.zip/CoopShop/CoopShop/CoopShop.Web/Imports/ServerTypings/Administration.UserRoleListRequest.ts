﻿namespace CoopShop.Administration {
    export interface UserRoleListRequest extends Serenity.ServiceRequest {
        UserID?: number;
    }
}

