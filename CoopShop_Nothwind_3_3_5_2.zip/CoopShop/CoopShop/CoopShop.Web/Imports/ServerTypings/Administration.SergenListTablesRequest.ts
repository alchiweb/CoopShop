﻿namespace CoopShop.Administration {
    export interface SergenListTablesRequest extends Serenity.ServiceRequest {
        ConnectionKey?: string;
    }
}
