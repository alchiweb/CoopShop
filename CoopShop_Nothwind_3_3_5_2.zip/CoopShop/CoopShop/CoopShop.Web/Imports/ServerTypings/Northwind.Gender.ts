﻿namespace CoopShop.Northwind {
    export enum Gender {
        Male = 1,
        Female = 2
    }
    Serenity.Decorators.registerEnum(Gender, 'CoopShop.Northwind.Entities.Gender');
}

