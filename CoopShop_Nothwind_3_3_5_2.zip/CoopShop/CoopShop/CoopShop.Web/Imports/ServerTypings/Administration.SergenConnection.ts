﻿namespace CoopShop.Administration {
    export interface SergenConnection {
        Key?: string;
    }
}
