﻿namespace CoopShop.Administration {
    export interface RolePermissionListResponse extends Serenity.ListResponse<string> {
    }
}

