﻿namespace CoopShop.BasicSamples {
    export interface OrdersByShipperRequest extends Serenity.ServiceRequest {
    }
}

