﻿
namespace CoopShop.DataShop.Entities
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    } 
}