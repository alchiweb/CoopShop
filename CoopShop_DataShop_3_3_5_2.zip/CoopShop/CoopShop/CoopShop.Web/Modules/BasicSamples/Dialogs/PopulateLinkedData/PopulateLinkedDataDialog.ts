﻿namespace CoopShop.BasicSamples {

    @Serenity.Decorators.registerClass()
    export class PopulateLinkedDataDialog extends Serenity.EntityDialog<DataShop.OrderRow, any> {

        protected getFormKey() { return PopulateLinkedDataForm.formKey; }
        protected getIdProperty() { return DataShop.OrderRow.idProperty; }
        protected getLocalTextPrefix() { return DataShop.OrderRow.localTextPrefix; }
        protected getNameProperty() { return DataShop.OrderRow.nameProperty; }
        protected getService() { return DataShop.OrderService.baseUrl; }

        protected form = new PopulateLinkedDataForm(this.idPrefix);

        constructor() {
            super();

            // "changeSelect2" is only fired when user changes the selection
            // but "change" is fired when dialog sets customer on load too
            // so we prefer "changeSelect2", as initial customer details 
            // will get populated by initial load, we don't want extra call
            this.form.CustomerID.changeSelect2(e => {
                var customerID = this.form.CustomerID.value;
                if (Q.isEmptyOrNull(customerID)) {
                    this.setCustomerDetails({});
                    return;
                }

                // in datashop CustomerID is a string like "ALFKI", 
                // while its actual integer ID value is 1.
                // so we need to convert customer ID to ID.
                // you won't have to do this conversion with your tables
                var id = Q.first(DataShop.CustomerRow.getLookup().items, x => x.CustomerID == customerID).ID;

                DataShop.CustomerService.Retrieve({
                    EntityId: id
                }, response => {
                    this.setCustomerDetails(response.Entity);
                });
            });
        }

        private setCustomerDetails(details: DataShop.CustomerRow) {
            this.form.CustomerCity.value = details.City;
            this.form.CustomerContactName.value = details.ContactName;
            this.form.CustomerContactTitle.value = details.ContactTitle;
            this.form.CustomerCountry.value = details.Country;
            this.form.CustomerFax.value = details.Fax;
            this.form.CustomerPhone.value = details.Phone;
            this.form.CustomerRegion.value = details.Region;
        }

        /**
         * This dialog will have CSS class "s-PopulateLinkedDataDialog"
         * We are changing it here to "s-OrderDialog", to make it use default OrderDialog styles
         * This has no effect other than looks on populate linked data demonstration
         */
        protected getCssClass() {
            return super.getCssClass() + " s-OrderDialog s-DataShop-OrderDialog";
        }



    }
}