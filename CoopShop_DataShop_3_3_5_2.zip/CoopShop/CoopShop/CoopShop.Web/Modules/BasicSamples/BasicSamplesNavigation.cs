﻿using Serenity.Navigation;

[assembly: NavigationMenu(7900, "Basic Samples", icon: "fa-magic")]
