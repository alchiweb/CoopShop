﻿namespace CoopShop.DataShop {
    export enum Gender {
        Male = 1,
        Female = 2
    }
    Serenity.Decorators.registerEnum(Gender, 'CoopShop.DataShop.Entities.Gender');
}

