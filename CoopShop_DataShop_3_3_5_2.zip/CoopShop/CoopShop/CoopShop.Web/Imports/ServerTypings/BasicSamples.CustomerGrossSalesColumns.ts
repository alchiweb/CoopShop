﻿namespace CoopShop.BasicSamples {
}

