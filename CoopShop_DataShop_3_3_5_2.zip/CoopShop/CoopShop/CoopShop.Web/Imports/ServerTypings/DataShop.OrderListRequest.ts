﻿namespace CoopShop.DataShop {
    export interface OrderListRequest extends Serenity.ListRequest {
        ProductID?: number;
    }
}

